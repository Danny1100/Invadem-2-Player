package invadem;

import org.junit.Test;
import static org.junit.Assert.*;

public class BarrierTest {

//    @Test
//    public void barrierConstruction() {
//        Barrier b = /* Your Constructor Here */
//        b.hit();
//        assertNotNull(b);
//    }

//    @Test
//    public void testBarrierNotDestroyed() {
//        Barrier b = /* Your Constructor Here */
//        assertEquals(false, b.isDestroyed());
//    }

//    @Test
//    public void testBarrierHitPointsMax() {
//        Barrier b = /* Your Constructor Here */
//        assertEquals(3, b.hitPoints());
//    }

//    @Test
//    public void testBarrierHitPointsMax() {
//        Barrier b = /* Your Constructor Here */
//        b.hit();
//        assertEquals(2, b.hitPoints());
//    }

//    @Test
//    public void testBarrierHitPointsMax() {
//        Barrier b = /* Your Constructor Here */
//        b.hit();
//        b.hit();
//        assertEquals(1, b.hitPoints());
//    }


//    @Test
//    public void testBarrierIsDestroyed() {
//        Barrier b = /* Your Constructor Here */
//        b.hit();
//        b.hit();
//        b.hit();
//        assertEquals(false, b.isDestroyed());
//    }

}
