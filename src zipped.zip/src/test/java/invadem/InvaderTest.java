package invadem;

import org.junit.Test;
import static org.junit.Assert.*;


public class InvaderTest {

//    @Test
//    public void testInvaderConstruction() {
//        Invader inv = /* Your Constructor Here */
//        assertNotNull(inv);

//    }

//    @Test
//    public void testInvaderFireProjectile() {
//        Invader inv = /* Your Constructor Here */
//        assertNotNull(inv.fire());
//    }

//    @Test
//    public void testInvaderIsNotDead() {
//        Invader inv = /* Your Constructor Here */
//        assertEquals(false, inv.isDead());
//    }

//    @Test
//    public void testInvaderIsDead() {
//        Invader inv = /* Your Constructor Here */
//        inv.hit();
//        assertEquals(true, inv.isDead());
//    }

//    @Test
//    public void testInvaderIntersectWithPlayerProjectile() {
//        Invader inv = /* Your Constructor Here */
//        Projectile proj = /* Your Constructor Here */
//        assertTrue(proj.intersect(inv));

//    }

//    @Test
//    public void testInvaderIntersectWithPlayerProjectile() {
//        Invader inv = /* Your Constructor Here */
//        Projectile proj = /* Your Constructor Here */
//        assertFalse(proj.intersect(inv));

//    }

}
