package invadem;
import processing.core.*;
public class Projectile extends Picture{
  public Projectile(PImage[] pic, int x, int y, int width, int height){
    super(pic, x, y, width, height);
  }
}
