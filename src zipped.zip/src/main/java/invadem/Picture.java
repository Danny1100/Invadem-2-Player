package invadem;
import processing.core.*;
public class Picture{
  private PImage[] pic;
  private int x;
  private int y;
  private int width;
  private int height;

  public Picture(PImage[] pic, int x, int y, int width, int height){
    this.pic = pic;
    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;
  }
  public PImage[] getPic(){
    return pic;
  }
  public int getX(){
    return x;
  }
  public int getY(){
    return y;
  }
  public int getWidth(){
    return width;
  }
  public int getHeight(){
    return height;
  }
  public void addX(){
    this.x += 1;
  }
  public void minusX(){
    this.x -= 1;
  }
  public void addY(){
    this.y += 1;
  }
  public void minusY(){
    this.y -= 1;
  }
  public int centrePicture(int width, int x){
    return x - width/2;
  }
  public boolean checkCollision(Picture p2){
    if ((this.getX() < p2.getX() + p2.getWidth()/2)
    && (p2.getX() < this.getX() + this.getWidth()/2)
    && (this.getY() < p2.getY() + p2.getHeight()/2)
    && (p2.getY() < this.getY() + this.getHeight()/2))
    {
      return true;
    }
    return false;
  }
}
