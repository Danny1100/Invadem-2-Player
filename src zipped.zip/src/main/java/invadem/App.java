package invadem;
import java.util.*;
import processing.core.*; //PApplet
import java.lang.Math;

public class App extends PApplet {
  public App() {}
Tank t;
ArrayList<Invader> invader_ls = new ArrayList<Invader>();
ArrayList<Barrier> barrier_ls = new ArrayList<Barrier>();
ArrayList<Projectile> projectile_ls = new ArrayList<Projectile>();
ArrayList<Projectile> invader_projectile_ls = new ArrayList<Projectile>();
boolean pressed_r = false;
boolean pressed_l = false;
boolean pressed_u = false;
    public void setup() {
        frameRate(60);

//tank starting position
        PImage tank_pic = loadImage("src/main/resources/tank1.png");
        t = new Tank(new PImage[] {tank_pic}, 3, 320, 450, tank_pic.width, tank_pic.height);

//invaders starting position
        PImage invader_pic1 = loadImage("src/main/resources/invader1.png");
        PImage invader_pic2 = loadImage("src/main/resources/invader2.png");
        for(int k = 0; k < 4; k++){
          int height_count = 70 + k*30;
          for(int j = 0; j < 10; j++){
            int gap_count = 170 + j * 30;
            Invader i = new Invader(new PImage[] {invader_pic1, invader_pic2}, gap_count, height_count, invader_pic1.width, invader_pic1.height);
            invader_ls.add(i);
          }
        }

//barrier starting position
        HashMap<Integer, String> barrier_names = new HashMap<Integer, String>();
        barrier_names.put(0, "left");
        barrier_names.put(1, "top");
        barrier_names.put(2, "right");
        barrier_names.put(3, "solid");

//top row of barriers
        for (int k = 0; k < 3; k++){
          int gap = k * 112;
          for(int i = 0; i < 3; i ++){
            PImage[] barrier_images = new PImage[3];
            for (int j = 0; j < 3; j++){
              PImage barrier_pic = loadImage("src/main/resources/barrier_" + barrier_names.get(i) + String.valueOf(j+1) + ".png");
              barrier_images[j] = barrier_pic;
            }
            Barrier b = new Barrier(barrier_images, 200 + i*8 + gap, 420, barrier_images[0].width, barrier_images[0].height);
            barrier_ls.add(b);
          }
        }

//middle and bottom row of barriers
        for (int l = 0; l < 2; l++){
          int row = l * 8;
          for (int k = 0; k < 3; k++){
            int gap = k * 112;
            for(int i = 0; i < 2; i ++){
              PImage[] barrier_images = new PImage[3];
              for (int j = 0; j < 3; j++){
                PImage barrier_pic = loadImage("src/main/resources/barrier_" + barrier_names.get(3) + String.valueOf(j+1) + ".png");
                barrier_images[j] = barrier_pic;
              }
              Barrier b = new Barrier(barrier_images, 200 + i*16 + gap, 428 + row, barrier_images[0].width, barrier_images[0].height);
              barrier_ls.add(b);
            }
          }
        }
    }

    public void settings() {
        size(640, 480);
    }

    int timer = 0;
    int move_count = 0;
    boolean down = false;

    public void draw() {
      background(0);

//moving tank
      if (pressed_l && t.getX() >= 180){
          t.minusX();
      }
      else if (pressed_r && t.getX() <= 460){
        t.addX();
      }
      image(t.getPic()[0], t.centrePicture(t.getWidth(), t.getX()), t.getY());

//drawing invaders
      if (down){
        for (Invader i : invader_ls){
          image(i.getPic()[1], i.centrePicture(i.getWidth(), i.getX()), i.getY());
        }
      }
      else{
        for (Invader i : invader_ls){
          image(i.getPic()[0], i.centrePicture(i.getWidth(), i.getX()), i.getY());
        }
      }

//moving invaders
      if(timer%2 == 0){
        if (move_count <= 30){
          for (Invader i : invader_ls){
            i.addX();
          }
          move_count++;
        }
        else if (move_count > 30 && move_count <= 38){
          down = true;
          for (Invader i : invader_ls){
            i.addY();
          }
          move_count++;
          if (move_count > 38){
            down = false;
          }
        }
        else if (move_count > 38 && move_count <= 68){
          for (Invader i : invader_ls){
            i.minusX();
          }
          move_count++;
        }
        else if (move_count > 68 && move_count <= 76){
          down = true;
          for (Invader i : invader_ls){
            i.addY();
          }
          move_count++;
          if (move_count > 76){
            move_count = 0;
            down = false;
          }
        }
      }

//drawing barriers
      for (Barrier b : barrier_ls){
        if (b.getHealth() == 3){
          image(b.getPic()[0], b.centrePicture(b.getWidth(), b.getX()), b.getY());
        }
        else if (b.getHealth() == 2){
          image(b.getPic()[1], b.centrePicture(b.getWidth(), b.getX()), b.getY());
        }
        else if (b.getHealth() == 1){
          image(b.getPic()[2], b.centrePicture(b.getWidth(), b.getX()), b.getY());
        }
      }

//removing barriers
      for (int i = 0; i < barrier_ls.size(); i++){
        if (barrier_ls.get(i).getHealth() == 0){
          barrier_ls.remove(i);
        }
      }

// removing tank and invader projectiles
      for (int i = 0; i < projectile_ls.size(); i++){
        if (projectile_ls.get(i).getY() < 0){
          projectile_ls.remove(i);
        }
      }

      for (int i = 0; i < invader_projectile_ls.size(); i++){
        if (invader_projectile_ls.get(i).getY() > 480){
          invader_projectile_ls.remove(i);
        }
      }

//drawing and moving tank projectiles
      if (projectile_ls != null){
        for (Projectile p : projectile_ls){
          if (p.getY() >= 0){
            image(p.getPic()[0], p.centrePicture(p.getWidth(), p.getX()), p.getY());
          }
        }
        for (Projectile p : projectile_ls){
          if (p.getY() >= 0){
            p.minusY();
          }
        }
      }

//invaders firing
      if(timer%20 == 0){                                                                 //change back to 300
        Projectile i_p = fire(invader_ls, loadImage("src/main/resources/projectile.png"));
        invader_projectile_ls.add(i_p);
      }

//drawing invader projectiles
      if (invader_projectile_ls != null){
        for (Projectile i_p : invader_projectile_ls){
          if (i_p.getY() <= 480){
            image(i_p.getPic()[0], i_p.centrePicture(i_p.getWidth(), i_p.getX()), i_p.getY());
          }
        }
        for (Projectile i_p : invader_projectile_ls){
          if (i_p.getY() <= 480){
            i_p.addY();
          }
        }
      }
// invader projectile collision function
      for(int i = 0; i < invader_projectile_ls.size(); i++){
        if (t.checkCollision(invader_projectile_ls.get(i))){
          t.loseLife();
          invader_projectile_ls.remove(i);
        }
        for(int j = 0; j < barrier_ls.size(); j++){
          if (invader_projectile_ls.get(i).checkCollision(barrier_ls.get(j))){
            barrier_ls.get(j).loseHealth();
            invader_projectile_ls.remove(i);
          }
        }
      }

//tank projectile collision function
      // for (int i = 0; i < projectile_ls.size(); i++){
      //   for(int j = 0; j < barrier_ls.size(); j++){
      //     if (projectile_ls.get(i).checkCollision(barrier_ls.get(j))){
      //       barrier_ls.get(j).loseHealth();
      //       projectile_ls.remove(i);
      //       continue;
      //     }
      //   }
      //   for(int k = 0; k < invader_ls.size(); k++){
      //     if (projectile_ls.get(i).checkCollision(invader_ls.get(k))){
      //       invader_ls.remove(k);
      //       projectile_ls.remove(i);
      //       continue;
      //     }
      //   }
      // }

//counting frames
      timer++;
    }

    public void keyPressed(){
      if (key == CODED){
        if (keyCode == LEFT){
          pressed_l = true;
        }
        else if (keyCode == RIGHT){
          pressed_r = true;
        }
        if (keyCode == UP){
          if (pressed_u == false){
            Projectile p = t.shoot(loadImage("src/main/resources/projectile.png"));
            projectile_ls.add(p);
            pressed_u = true;
          }
        }
      }
    }
    public void keyReleased(){
      if (key == CODED){
        if (keyCode == LEFT){
          pressed_l = false;
        }
        else if (keyCode == RIGHT){
          pressed_r = false;
        }
        else if (keyCode == UP){
          pressed_u = false;
        }
      }
    }

//function for invader firing
    public Projectile fire(ArrayList<Invader> ls, PImage graphic){
      int min = 0;
      int max = ls.size() - 1;
      int num = (int)(Math.random()*((max-min) + 1)) + min;
      Invader i = ls.get(num);
      return new Projectile(new PImage[] {graphic}, i.getX(), i.getY() + 10, 1, 3);
    }

    public static void main(String[] args) {
        PApplet.main("invadem.App");
    }
}
